
-- --------------------------------------------------------

--
-- Table structure for table `bookborrow`
--

DROP TABLE IF EXISTS `bookborrow`;
CREATE TABLE `bookborrow` (
  `borrowid` int(11) NOT NULL,
  `borrowerid` varchar(10) DEFAULT NULL,
  `ISBN` varchar(17) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookborrow`
--

INSERT INTO `bookborrow` (`borrowid`, `borrowerid`, `ISBN`, `status`) VALUES
(1, 'CSB19029', '973-3-12-567894-1', 'Approved');

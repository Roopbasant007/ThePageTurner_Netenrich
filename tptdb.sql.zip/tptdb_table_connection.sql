
-- --------------------------------------------------------

--
-- Table structure for table `connection`
--

DROP TABLE IF EXISTS `connection`;
CREATE TABLE `connection` (
  `connid` int(11) NOT NULL,
  `sender` varchar(10) DEFAULT NULL,
  `receiver` varchar(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `connection`
--

INSERT INTO `connection` (`connid`, `sender`, `receiver`, `status`) VALUES
(1, 'CSB19029', 'CSB19018', 'Pending'),
(2, 'CSB19030', 'CSB19012', 'Pending');

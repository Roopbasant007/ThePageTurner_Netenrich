
-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `title` varchar(150) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `genre` varchar(30) DEFAULT NULL,
  `year_of_publication` int(11) DEFAULT NULL,
  `ISBN` varchar(17) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`title`, `author`, `genre`, `year_of_publication`, `ISBN`, `status`) VALUES
('Fundamental of C programming', 'K. Richie', 'Science', 2019, '973-3-12-567894-1', 1),
('Fundamental Of R programming For Machine learning', 'James Halder', 'Science', 2019, '973-5-16-768943-8', 0),
('Fundamental of R programming', 'James Halder', 'Science', 2019, '978-5-16-567894-6', 0),
('Fundamental of Python programming', 'J. Richie', 'Science', 2019, '978-8-12-567894-6', 0);


--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `ix_admins_email` (`email`),
  ADD KEY `ix_admins_name` (`name`),
  ADD KEY `ix_admins_year_of_joining` (`year_of_joining`),
  ADD KEY `ix_admins_password` (`password`);

--
-- Indexes for table `bookborrow`
--
ALTER TABLE `bookborrow`
  ADD PRIMARY KEY (`borrowid`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`ISBN`),
  ADD KEY `ix_books_author` (`author`),
  ADD KEY `ix_books_genre` (`genre`),
  ADD KEY `ix_books_year_of_publication` (`year_of_publication`),
  ADD KEY `ix_books_ISBN` (`ISBN`),
  ADD KEY `ix_books_title` (`title`);

--
-- Indexes for table `connection`
--
ALTER TABLE `connection`
  ADD PRIMARY KEY (`connid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`rollno`),
  ADD UNIQUE KEY `ix_students_email` (`email`),
  ADD KEY `ix_students_rollno` (`rollno`),
  ADD KEY `ix_students_year_of_admission` (`year_of_admission`),
  ADD KEY `ix_students_name` (`name`),
  ADD KEY `ix_students_course` (`course`),
  ADD KEY `ix_students_dept` (`dept`),
  ADD KEY `ix_students_password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookborrow`
--
ALTER TABLE `bookborrow`
  MODIFY `borrowid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `connection`
--
ALTER TABLE `connection`
  MODIFY `connid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

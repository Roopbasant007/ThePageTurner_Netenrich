
-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `rollno` varchar(8) NOT NULL,
  `name` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `year_of_admission` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`rollno`, `name`, `course`, `dept`, `year_of_admission`, `email`, `password`) VALUES
('CSB19012', 'Vikrant', 'B.Tech', 'CSE', 2019, 'vik00djfk1@gmail.com', '$2b$12$KEqW.LmyhhsV6j6Dt03Ff.rIk5AkVjIyfEn/mqqIkgnnekySBWoJi'),
('CSB19013', 'Vikrant', 'B.Tech', 'CSE', 2019, 'vik00djxcvfk1@gmail.com', '$2b$12$BIE0UmTn9MY3j39wM/Srw.GydIB3UpjWNNX3P5HxULCB0N.zzW2K.'),
('CSB19014', 'Bikrant', 'B.Tech', 'CSE', 2019, 'vik00djxcvfksdsad1ed@gmail.com', '$2b$12$/GZGxbbHhZ4xsa11pq4IYu93KEE.75knIayEfXVwwMf0Tjq2qF7Hm'),
('CSB19015', 'Vikrant', 'B.Tech', 'CSE', 2019, 'vik00djxcvfksdsad1@gmail.com', '$2b$12$WOXkn2GX9YQTisS.tXv5C.9PkcSYJam5MLbTeevmEYgdHjBEgm50C'),
('CSB19016', 'Bikrant', 'B.Tech', 'CSE', 2019, 'vik00djxcvfksdsad1zxced@gmail.com', '$2b$12$g6Q8oPRMx/sRHPCACTcUDOIk4ffbHugnMnavbiUEDH1OVYQSjX4Iq'),
('CSB19017', 'Bikrant', 'B.Tech', 'CSE', 2019, 'vik00djone@gmail.com', '$2b$12$gnElV01nhKiAygoP/CugMe8I7NTaPpi7LSCgef/siWmZJ/maGiMCe'),
('CSB19018', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjone@gmail.com', '$2b$12$MoNb44SEQbXgu5iHTX3DH.HTLXjc6u4qNb80HohkS.PqFnmrg5PpW'),
('CSB19019', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjoxcne@gmail.com', '$2b$12$Ucmh19tV64r0iteRjW5vpOZG/4S9YVM0nVcGLvcGQ6bL4vl47WGFW'),
('CSB19020', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjoxcxcne@gmail.com', '$2b$12$tJZzLwzFOOLSnby3RtB6GevWBopylkyKVgtKBVnVQ4MFtX46dLnHe'),
('CSB19021', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjoxcxsdcne@gmail.com', '$2b$12$6hboVeVCUocNOC/SDMrDpeluq/LNUcZe6gGX53E9CMemUUoLxOCQi'),
('CSB19022', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjoxcxsdcxccne@gmail.com', '$2b$12$fQZNEs4CM11uFQyZc2/8feLfqVkxUjrlmU4UWsS0FVqqkTrWv5XaK'),
('CSB19023', 'Rajdeep', 'B.Tech', 'CSE', 2019, 'rajjoxxccne@gmail.com', '$2b$12$494m7PYZX8mCqVoMLFt/6eN7hLKn/l27l9xqICEwqY.pN6rg.cP4y'),
('CSB19025', 'Pranav', 'B.Tech', 'CSE', 2019, 'pranave@gmail.com', '$2b$12$iqDFlRfmKBeLjYbj6/cO4O3jnbB3UZwsv5XCYHvCIyFy/qeX.X7Yq'),
('CSB19026', 'Pranav pragyan', 'B.Tech', 'CSE', 2019, 'pranave002@gmail.com', '$2b$12$dRY.qRz3vZWUZxtB8oWbweeYHCyW/z/OumuFimlWQaP0iG5.Qihz6'),
('CSB19027', 'Udit', 'B.Tech', 'CSE', 2019, 'Uditnzone002@gmail.com', '$2b$12$YV3w1dlWxjDiLIGUaBZUCuIA4NGphPUQsSsCMUuS6NLhTdze8HDja'),
('CSB19028', 'Udit jha2', 'B.Tech', 'CSE', 2019, 'Uditnzone001@gmail.com', '$2b$12$/L0udpGcuoSmMzwqoS9ZfudvOoTzuQNFcoiurDiFKtY.92deZncLS'),
('CSB19029', 'Mukesh', 'B.Tech', 'CSE', 2019, 'Mukeshnzone001@gmail.com', '$2b$12$dlavAK2a5oUwraXU.kvDTuq8vaNBVfGv9HEiRdat0yFmqMMX7l10i'),
('CSB19030', 'Sukesh', 'B.Tech', 'CSE', 2019, 'Sukeshnzone001@gmail.com', '$2b$12$1LwIqtQ3PlM4julFL/f3PuieDTc2WB0cKe2EQQVEXbfK.ZqvJxe/2');

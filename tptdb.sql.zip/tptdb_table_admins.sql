
-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `name` varchar(50) NOT NULL,
  `year_of_joining` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`name`, `year_of_joining`, `email`, `password`) VALUES
('Sukesh', 2019, 'Sukeshnzone001@gmail.com', '$2b$12$l18jvHcjZi4aqD99F3agWuprBCA13ERooSrxY8t.Vc7ZaErrQVjBi');
